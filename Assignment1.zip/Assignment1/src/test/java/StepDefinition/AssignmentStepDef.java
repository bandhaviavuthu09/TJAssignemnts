package StepDefinition;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AssignmentStepDef {
	WebDriver driver = new ChromeDriver();
	
	@Given("Launch Elearning upskill website")
	public void launch_Elearning_upskill_website() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\002OER744\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		
		driver.get("http://elearningm1.upskills.in/index.php");
		driver.manage().window().maximize();
	
	}

	@And("Verify the SignUp btn is displayed")
	public void verify_the_SignUp_btn_is_displayed() {
		System.out.println(driver.findElement(By.xpath("//a[contains(text(),'Sign up!')]")).isDisplayed());
	}

	@And("Click on SignUp")
	public void click_on_SignUp() {
		driver.findElement(By.xpath("//a[contains(text(),'Sign up!')]")).click();
	}

	@And("Fill registration form and Submit details and verify {string}")
	public void fill_registration_form_and_Submit_details_and_verify(String string, io.cucumber.datatable.DataTable dataTable) {
		
		Map<String, String> data = dataTable.asMap(String.class,String.class);
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys(data.get("firstName"));
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys(data.get("lastName"));
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys(data.get("email"));
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(data.get("userName"));
		driver.findElement(By.xpath("//input[@name='pass1']")).sendKeys(data.get("pass1"));
		driver.findElement(By.xpath("//input[@name='pass2']")).sendKeys(data.get("pass2"));
		driver.findElement(By.xpath("//button[@name='submit']")).click();
		System.out.println(driver.findElement(By.xpath("//p[contains(text()[2],'Your personal settings have been registered.')]")).isDisplayed());
		driver.findElement(By.xpath("//button[@name='next']")).click();
	}

	@When("User homepage is displayed click username")
	public void user_homepage_is_displayed_click_username() {
		System.out.println(driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).isDisplayed());
		driver.findElement(By.xpath("//a[@class='dropdown-toggle']")).click();
	}

	@And("Verify the profiles are displayed")
	public void verify_the_profiles_are_displayed() {
		System.out.println(driver.findElement(By.xpath("//li[@class='dropdown open']")).isDisplayed());
		
	}

	@Then("Click on Inbox")
	public void click_on_Inbox() {
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
	}

	@And("Click on Compose message and enter all details {string}")
	public void click_on_Compose_message_and_enter_all_details(String string, io.cucumber.datatable.DataTable dataTable) throws InterruptedException {
		
		Map<String, String> data = dataTable.asMap(String.class,String.class);
		driver.findElement(By.xpath("//div[@id='toolbar']//a[contains(@href,'new_message')]")).click();
		driver.findElement(By.xpath("//input[@class='select2-search__field']")).sendKeys(data.get("To"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Abcd Pqrs')]")).click();
		driver.findElement(By.xpath("//input[@name='title']")).sendKeys(data.get("Subject"));
	}

	@And("Click on Send Message")
	public void click_on_Send_Message() {
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.close();
	}

}
